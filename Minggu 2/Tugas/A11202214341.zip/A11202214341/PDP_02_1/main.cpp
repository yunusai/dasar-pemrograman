#include <iostream>
/*
Muhammad Yunus Saifullah (A11.2022.14341)
Selasa, 13 September 2022
Nama Dosen = Bu Nurul Anisa Sri Winarsih (Bu Nurul)\
*/
using namespace std;

int main()
{
    string ayah, ibu;//deklarasi variabel nama

    ayah = "Joko Sujoko";//deklarasi nilai variabel
    ibu = "Ani Sakani";//deklarasi nilai variabel

    cout << "Yah, Masa nama orang tua sendiri lupa sih, Mawar. Yaudah cuma sekali ini saja kubantu ingat ingat" << endl;
    cout<<"Nama ayahmu itu pak "<<ayah<<" dan nama ibumu itu bu "<<ibu<<endl;//perintah untuk menampilkan hasil
    return 0;
}

