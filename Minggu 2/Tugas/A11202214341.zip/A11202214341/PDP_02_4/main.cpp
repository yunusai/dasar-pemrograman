#include <iostream>
/*
Muhammad Yunus Saifullah (A11.2022.14341)
Selasa, 13 September 2022
Nama Dosen = Bu Nurul Anisa Sri Winarsih (Bu Nurul)\
*/

using namespace std;
int main()
{
    int a, b;//belum dideklarasi sebagai variabel
//Kamus
    a = 1;//belum dikasih ;
    b = 4;//belum dikasih ;
//Algoritma
    cout << "Hasil a yang pertama: "<<a<<endl;//belum dikasih <<
    cout << "Hasil b yang pertama: "<<b<<endl;//belum dikasih <<
    b = a;
    a = -b;
    cout << "Hasil a yang kedua: "<<a<<endl;//belum dikasih <<
    cout << "Hasil b yang kedua: "<<b<<endl;//belum dikasih <<
    a = b + 1;
    b = a / b;
    cout << "Hasil a yang ketiga: "<<a<<endl;//belum dikasih <<
    cout << "Hasil b yang ketiga: "<<b<<endl;//belum dikasih <<
 return 0;
}
