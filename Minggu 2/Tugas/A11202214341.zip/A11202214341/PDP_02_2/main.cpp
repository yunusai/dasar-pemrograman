#include <iostream>
/*
Muhammad Yunus Saifullah (A11.2022.14341)
Selasa, 13 September 2022
Nama Dosen = Bu Nurul Anisa Sri Winarsih (Bu Nurul)\
*/
using namespace std;

int main()
{
    int x, y, hasil;//deklarasi variabel

    x = 4;//deklarasi nilai variabel
    y = 6;//deklarasi nilai variabel
    hasil = 2*x + 5*y;//perintah untuk menghitung hasil

    cout<<"Hasil dari operasi matematika 2x + 5y dengan nilai x = "<<x<<" dan y = "<<y<<"\nadalah "<<hasil;//perintah untuk menampilkan hasil

    return 0;
}
